#!/usr/bin/env python
from numpyx import test
test()
