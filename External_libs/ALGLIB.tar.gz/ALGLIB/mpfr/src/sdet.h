/*************************************************************************
Copyright (c) 2005-2007, Sergey Bochkanov (ALGLIB project).

>>> SOURCE LICENSE >>>
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation (www.fsf.org); either version 2 of the 
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

A copy of the GNU General Public License is available at
http://www.fsf.org/licensing/licenses

>>> END OF LICENSE >>>
*************************************************************************/

#ifndef _sdet_h
#define _sdet_h

#include "ap.h"
#include "amp.h"
#include "ldlt.h"
namespace sdet
{
    template<unsigned int Precision>
    amp::ampf<Precision> smatrixldltdet(const ap::template_2d_array< amp::ampf<Precision> >& a,
        const ap::template_1d_array< int >& pivots,
        int n,
        bool isupper);
    template<unsigned int Precision>
    amp::ampf<Precision> smatrixdet(ap::template_2d_array< amp::ampf<Precision> > a,
        int n,
        bool isupper);
    template<unsigned int Precision>
    amp::ampf<Precision> determinantldlt(const ap::template_2d_array< amp::ampf<Precision> >& a,
        const ap::template_1d_array< int >& pivots,
        int n,
        bool isupper);
    template<unsigned int Precision>
    amp::ampf<Precision> determinantsymmetric(ap::template_2d_array< amp::ampf<Precision> > a,
        int n,
        bool isupper);


    /*************************************************************************
    Determinant calculation of the matrix given by LDLT decomposition.

    Input parameters:
        A       -   LDLT-decomposition of the matrix,
                    output of subroutine SMatrixLDLT.
        Pivots  -   table of permutations which were made during
                    LDLT decomposition, output of subroutine SMatrixLDLT.
        N       -   size of matrix A.
        IsUpper -   matrix storage format. The value is equal to the input
                    parameter of subroutine SMatrixLDLT.

    Result:
        matrix determinant.

      -- ALGLIB --
         Copyright 2005-2008 by Bochkanov Sergey
    *************************************************************************/
    template<unsigned int Precision>
    amp::ampf<Precision> smatrixldltdet(const ap::template_2d_array< amp::ampf<Precision> >& a,
        const ap::template_1d_array< int >& pivots,
        int n,
        bool isupper)
    {
        amp::ampf<Precision> result;
        int k;


        result = 1;
        if( isupper )
        {
            k = 0;
            while( k<n )
            {
                if( pivots(k)>=0 )
                {
                    result = result*a(k,k);
                    k = k+1;
                }
                else
                {
                    result = result*(a(k,k)*a(k+1,k+1)-a(k,k+1)*a(k,k+1));
                    k = k+2;
                }
            }
        }
        else
        {
            k = n-1;
            while( k>=0 )
            {
                if( pivots(k)>=0 )
                {
                    result = result*a(k,k);
                    k = k-1;
                }
                else
                {
                    result = result*(a(k-1,k-1)*a(k,k)-a(k,k-1)*a(k,k-1));
                    k = k-2;
                }
            }
        }
        return result;
    }


    /*************************************************************************
    Determinant calculation of the symmetric matrix

    Input parameters:
        A       -   matrix. Array with elements [0..N-1, 0..N-1].
        N       -   size of matrix A.
        IsUpper -   if IsUpper = True, then symmetric matrix A is given by its
                    upper triangle, and the lower triangle isn�t used by
                    subroutine. Similarly, if IsUpper = False, then A is given
                    by its lower triangle.

    Result:
        determinant of matrix A.

      -- ALGLIB --
         Copyright 2005-2008 by Bochkanov Sergey
    *************************************************************************/
    template<unsigned int Precision>
    amp::ampf<Precision> smatrixdet(ap::template_2d_array< amp::ampf<Precision> > a,
        int n,
        bool isupper)
    {
        amp::ampf<Precision> result;
        ap::template_1d_array< int > pivots;


        ldlt::smatrixldlt<Precision>(a, n, isupper, pivots);
        result = smatrixldltdet<Precision>(a, pivots, n, isupper);
        return result;
    }


    template<unsigned int Precision>
    amp::ampf<Precision> determinantldlt(const ap::template_2d_array< amp::ampf<Precision> >& a,
        const ap::template_1d_array< int >& pivots,
        int n,
        bool isupper)
    {
        amp::ampf<Precision> result;
        int k;


        result = 1;
        if( isupper )
        {
            k = 1;
            while( k<=n )
            {
                if( pivots(k)>0 )
                {
                    result = result*a(k,k);
                    k = k+1;
                }
                else
                {
                    result = result*(a(k,k)*a(k+1,k+1)-a(k,k+1)*a(k,k+1));
                    k = k+2;
                }
            }
        }
        else
        {
            k = n;
            while( k>=1 )
            {
                if( pivots(k)>0 )
                {
                    result = result*a(k,k);
                    k = k-1;
                }
                else
                {
                    result = result*(a(k-1,k-1)*a(k,k)-a(k,k-1)*a(k,k-1));
                    k = k-2;
                }
            }
        }
        return result;
    }


    template<unsigned int Precision>
    amp::ampf<Precision> determinantsymmetric(ap::template_2d_array< amp::ampf<Precision> > a,
        int n,
        bool isupper)
    {
        amp::ampf<Precision> result;
        ap::template_1d_array< int > pivots;


        ldlt::ldltdecomposition<Precision>(a, n, isupper, pivots);
        result = determinantldlt<Precision>(a, pivots, n, isupper);
        return result;
    }
} // namespace

#endif
